# Question 3. Write a function called increment, which adds 1 to its argument.
# An example call is: n = 3 a = Increment(n);

def Increment(n):
    return n+1

print(Increment(2))
