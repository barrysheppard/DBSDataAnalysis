test = ["One","Two","Three"]
for x in test:
    print(x)
